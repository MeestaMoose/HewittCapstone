package com.zybooks.project2hhewitt;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private Switch smsSwitch;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.smsnotifications);

        smsSwitch = findViewById(R.id.switch1);
        sharedPreferences = getSharedPreferences("SmsPrefs", MODE_PRIVATE);

        // Load saved state
        boolean isEnabled = sharedPreferences.getBoolean("sms_enabled", false);
        smsSwitch.setChecked(isEnabled);

        smsSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                checkPermissionAndEnable();
            } else {
                saveSmsPreference(false);
            }
        });
    }

    private void checkPermissionAndEnable() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            saveSmsPreference(true);
        }
    }

    private void saveSmsPreference(boolean enabled) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("sms_enabled", enabled);
        editor.apply();
        
        if (enabled) {
            Toast.makeText(this, "SMS Notifications Enabled", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "SMS Notifications Disabled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsPreference(true);
            } else {
                smsSwitch.setChecked(false);
                saveSmsPreference(false);
                Toast.makeText(this, "Permission denied. Cannot enable SMS notifications.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
