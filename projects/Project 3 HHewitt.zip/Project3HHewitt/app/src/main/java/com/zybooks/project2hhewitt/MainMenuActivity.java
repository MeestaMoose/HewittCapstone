package com.zybooks.project2hhewitt;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity {

    // --- UI Elements ---
    private Button inventoryButton;
    private Button smsButton;
    private Button logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);

        // Initialize UI components
        inventoryButton = findViewById(R.id.inventorymanagerbutton);
        smsButton = findViewById(R.id.smsbutton);
        logoutButton = findViewById(R.id.logoutbutton);

        // Navigation logic for Inventory Manager
        inventoryButton.setOnClickListener(view -> {
            startActivity(new Intent(this, InventoryActivity.class));
        });

        // Navigation logic for SMS Notifications
        smsButton.setOnClickListener(view -> {
            startActivity(new Intent(this, SmsActivity.class));
        });

        // Navigation logic for Logout
        logoutButton.setOnClickListener(view -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish(); // Close the menu on logout
        });
    }
}
