package com.zybooks.project2hhewitt;

import android.content.Context;
import android.content.SharedPreferences;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {
    // --- Member Variables ---
    private List<Item> itemList;
    private AppDatabase db;

    // --- Constructor ---
    public ItemAdapter(List<Item> itemList, AppDatabase db) {
        this.itemList = itemList;
        this.db = db;
    }

    // --- ViewHolder Class ---
    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView itemName;
        public TextView itemDescription;
        public TextView itemQuantity;
        public Button btnIncrease, btnDecrease, btnRemove;

        public ViewHolder(View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemDescription = itemView.findViewById(R.id.itemDescription);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            btnIncrease = itemView.findViewById(R.id.btnIncrease);
            btnDecrease = itemView.findViewById(R.id.btnDecrease);
            btnRemove = itemView.findViewById(R.id.btnRemove);
        }
    }

    // --- Adapter Lifecycle Methods ---
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // Get the current item from the list
        Item item = itemList.get(position);
        
        // Display item data in the views
        holder.itemName.setText(item.getName());
        holder.itemDescription.setText(item.getDescription());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        // Increase quantity button logic
        holder.btnIncrease.setOnClickListener(v -> {
            item.quantity++;
            db.itemDao().update(item); // Save change to database
            notifyItemChanged(position); // Refresh UI
        });

        // Decrease quantity button logic
        holder.btnDecrease.setOnClickListener(v -> {
            if (item.quantity > 0) {
                item.quantity--;
                db.itemDao().update(item); // Save change to database
                notifyItemChanged(position); // Refresh UI
                checkSmsNotification(holder.itemView.getContext(), item); // Check for low stock
            }
        });

        // Remove item button logic
        holder.btnRemove.setOnClickListener(v -> {
            db.itemDao().delete(item); // Remove from database
            itemList.remove(position); // Remove from local list
            notifyItemRemoved(position); // Update UI
            notifyItemRangeChanged(position, itemList.size());
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // --- Helper Methods ---
    private void checkSmsNotification(Context context, Item item) {
        // Trigger SMS if quantity is below 3
        if (item.quantity < 3) {
            // Check user preferences for SMS
            SharedPreferences prefs = context.getSharedPreferences("SmsPrefs", Context.MODE_PRIVATE);
            boolean isEnabled = prefs.getBoolean("sms_enabled", false);

            if (isEnabled) {
                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    // Send alert to pre-defined number
                    smsManager.sendTextMessage("5551234567", null,
                        "Low stock alert: " + item.getName() + " is down to " + item.getQuantity(), null, null);
                    Toast.makeText(context, "Low stock SMS sent", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(context, "SMS failed to send", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }


}
