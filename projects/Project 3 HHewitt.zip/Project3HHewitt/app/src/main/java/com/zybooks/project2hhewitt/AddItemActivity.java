package com.zybooks.project2hhewitt;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    // --- UI Elements ---
    private EditText itemName;
    private EditText itemDescription;
    private EditText itemQuantity;
    private Button submitButton;

    // --- Database ---
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item_screen);

        // Initialize UI components
        itemName = findViewById(R.id.itemName);
        itemDescription = findViewById(R.id.itemDescription);
        itemQuantity = findViewById(R.id.itemQuantity);
        submitButton = findViewById(R.id.submitButton);

        // Get database instance
        db = AppDatabase.getInstance(this);

        // Submit button logic
        submitButton.setOnClickListener(view -> {
            String name = itemName.getText().toString();
            String description = itemDescription.getText().toString();
            String quantityStr = itemQuantity.getText().toString();

            // Validation
            if (name.isEmpty() || description.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    // Convert and save item
                    int quantity = Integer.parseInt(quantityStr);
                    Item item = new Item(name, description, quantity);
                    db.itemDao().insert(item);

                    Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                    finish(); // Close activity after success
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Please enter a valid number for quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
