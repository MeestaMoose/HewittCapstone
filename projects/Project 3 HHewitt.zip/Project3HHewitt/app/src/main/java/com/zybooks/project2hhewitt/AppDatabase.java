package com.zybooks.project2hhewitt;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {User.class, Item.class}, version = 3)
public abstract class AppDatabase extends RoomDatabase {
    // --- Singleton Instance ---
    private static AppDatabase instance;

    // --- DAOs ---
    public abstract UserDAO userDao();
    public abstract ItemDAO itemDao();

    // --- Database Singleton Accessor ---
    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            // Build database with destructive migration enabled for development
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "my-database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return instance;
    }
}
