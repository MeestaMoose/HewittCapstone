package com.zybooks.project2hhewitt;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // --- UI Elements ---
    private EditText usernameInput;
    private EditText passwordInput;
    private Button submitButton;
    private Button createAccountButton;

    // --- Database ---
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        // Initialize UI components
        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        submitButton = findViewById(R.id.submit_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Get database instance
        db = AppDatabase.getInstance(this);

        // Login button logic
        submitButton.setOnClickListener(view -> {
            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();

            // Check credentials against database
            User user = db.userDao().login(username, password);

            if (user != null) {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
                // Navigate to Main Menu on success
                startActivity(new Intent(this, MainMenuActivity.class));
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // Navigate to Registration screen
        createAccountButton.setOnClickListener(view -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }
}
