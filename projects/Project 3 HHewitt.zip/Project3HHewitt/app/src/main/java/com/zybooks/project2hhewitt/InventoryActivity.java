package com.zybooks.project2hhewitt;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    // --- Member Variables ---
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private AppDatabase db;
    private FloatingActionButton fabAddItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_screen);

        // Initialize UI components
        fabAddItem = findViewById(R.id.floatingActionButton);
        recyclerView = findViewById(R.id.inventoryRecyclerView);

        // Set up the floating action button to add new items
        fabAddItem.setOnClickListener(view -> {
            startActivity(new Intent(this, AddItemActivity.class));
        });

        // Initialize database and recycler view
        db = AppDatabase.getInstance(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        
        // Load initial data
        refreshItemList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh the list when returning to this screen
        refreshItemList();
    }

    // --- Helper Methods ---
    private void refreshItemList() {
        List<Item> itemList = db.itemDao().getAllItems();
        itemAdapter = new ItemAdapter(itemList, db);
        recyclerView.setAdapter(itemAdapter);
    }
}
